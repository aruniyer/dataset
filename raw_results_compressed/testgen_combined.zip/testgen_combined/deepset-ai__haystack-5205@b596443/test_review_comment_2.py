import re


def test_constructor_model_kwargs_checks_temperature_value_explicitly():
    """
    Verify the review change: the test should assert the concrete value of temperature
    rather than only checking the key exists.

    This is intentionally a source-level inspection because importing the module under
    test fails in this environment (pydantic schema error).
    """
    source = open("/workspace/test/prompt/invocation_layer/test_sagemaker_hf_infer.py", "r", encoding="utf-8").read()

    # The improved check requested in the review comment: assert exact temperature value.
    expected_line = 'assert layer.model_input_kwargs["temperature"] == 0.7'
    assert (
        expected_line in source
    ), f"Expected the test to include an explicit temperature value assertion: {expected_line!r}"

    # Ensure we didn't keep the weaker presence-only assertion for temperature.
    weak_pattern = re.compile(r'assert\s+"temperature"\s+in\s+layer\.model_input_kwargs')
    assert not weak_pattern.search(
        source
    ), 'Did not expect the weaker check `assert "temperature" in layer.model_input_kwargs` to remain.'