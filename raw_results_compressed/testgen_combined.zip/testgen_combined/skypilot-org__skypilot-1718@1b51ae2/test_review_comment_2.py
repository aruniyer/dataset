import inspect

import sky.skylet.providers.lambda_cloud.node_provider as node_provider


def test_create_node_uses_fullname_instance_type_variable():
    """Style regression test: create_node should use a descriptive local name.

    Review requested using fullname `instance_type` rather than abbreviated
    `ttype` for the variable holding node_config['InstanceType'].
    This is not observable at runtime, so we validate via source inspection.
    """
    source = inspect.getsource(node_provider.LambdaNodeProvider.create_node)

    assert "instance_type = node_config['InstanceType']" in source, (
        "Expected LambdaNodeProvider.create_node() to assign "
        "node_config['InstanceType'] to a local variable named "
        "`instance_type` (full name), per style review comment."
    )
    assert "ttype = node_config['InstanceType']" not in source, (
        "Found abbreviated local variable `ttype` for instance type in "
        "LambdaNodeProvider.create_node(); expected full name `instance_type`."
    )