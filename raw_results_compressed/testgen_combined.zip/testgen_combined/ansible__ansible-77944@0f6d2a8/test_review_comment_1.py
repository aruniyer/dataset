import pytest

from ansible.parsing.dataloader import DataLoader
from ansible.inventory.host import Host
from lib.ansible.inventory.manager import InventoryManager


def test_refresh_inventory_replays_cached_dynamic_grouping_without_re_adding_removed_host():
    """
    Verify the post-fix behavior for cached dynamic group_by data:

    - InventoryManager.add_dynamic_group() should cache the full result dict, including
      add_group and parent_groups, so refresh_inventory can replay the grouping structure.
    - During refresh, if the original host no longer exists in the refreshed inventory,
      the replay should be skipped (no exception, but also no groups created).
      This avoids inventing grouping structure for hosts that disappeared.
    """
    loader = DataLoader()
    inv = InventoryManager(loader, sources=[], parse=False)

    inv.add_host("seedhost", "all")
    executor_host = Host("seedhost")

    result = {"add_group": "dyn_group", "parent_groups": ["parent1", "parent2"]}
    inv.add_dynamic_group(executor_host, result)

    # Sanity precondition: dynamic groups/structure exists prior to refresh.
    assert "dyn_group" in inv.groups, "Precondition: dynamic group should exist before inventory refresh"
    assert "parent1" in inv.groups and "parent2" in inv.groups, "Precondition: parent groups should exist before refresh"

    # Simulate that the refreshed inventory will NOT contain the original host
    # (e.g., inventory source changed). The correct behavior on refresh is:
    # skip replaying group_by for the missing host, and do not create groups.
    inv._inventory.hosts.pop("seedhost", None)

    inv.refresh_inventory()

    assert "dyn_group" not in inv.groups, (
        "On inventory refresh, cached dynamic grouping should be skipped for hosts that no longer exist; "
        "dynamic groups must not be recreated without their host"
    )
    assert "parent1" not in inv.groups and "parent2" not in inv.groups, (
        "Parent groups from cached dynamic grouping must not be recreated during refresh if the host is missing"
    )