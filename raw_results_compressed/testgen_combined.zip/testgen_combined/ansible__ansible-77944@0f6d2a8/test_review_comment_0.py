import pytest

from ansible.parsing.dataloader import DataLoader
from lib.ansible.inventory.manager import InventoryManager


def test_add_dynamic_host_caches_when_called_from_playbook_not_when_refreshing():
    """
    Regression test for reversed caching condition in InventoryManager.add_dynamic_host().

    Expected behavior (fixed code):
      - When called from playbook execution, result_item is a populated dict -> cache host_info.
      - When called during refresh, result_item contains {'refresh': True} -> do NOT cache again.

    Before code bug:
      - It cached only when result_item was falsy, so playbook calls never cached and refresh did.
    """
    mgr = InventoryManager(DataLoader(), sources=[], parse=False)

    host_info = {"host_name": "dyn1", "host_vars": {"a": 1}, "groups": []}

    # Simulate being called from a playbook/task result: result_item is populated.
    play_result = {"some": "data"}
    mgr.add_dynamic_host(host_info, play_result)

    assert mgr._cached_dynamic_hosts == [host_info], (
        "add_dynamic_host() should cache host_info when result_item is populated (playbook call). "
        "This ensures refresh_inventory() can replay dynamic hosts later."
    )

    # Simulate refresh replay: must NOT re-cache the same host_info when refresh=True.
    mgr.add_dynamic_host(host_info, {"refresh": True})

    assert mgr._cached_dynamic_hosts == [host_info], (
        "add_dynamic_host() must not append to _cached_dynamic_hosts when called during inventory refresh "
        "(result_item contains refresh=True), to avoid duplicate caching/growth."
    )