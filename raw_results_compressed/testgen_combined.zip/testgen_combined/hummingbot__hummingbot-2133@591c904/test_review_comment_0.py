import pytest

from hummingbot.core.data_type.trade import Trade
from hummingbot.core.event.events import OrderType, TradeType, TradeFee


def test_trade_to_pandas_uses_enum_name_lower_for_order_type_and_side():
    """
    The review comment implies we should not hardcode mappings like:
      "limit" if ... else "limit_maker"  and  "buy" if ... else "sell"
    Instead, to_pandas should use enum values directly via .name.lower().
    This test ensures the DataFrame contains the enum-derived strings for both fields.
    """
    trade = Trade(
        trading_pair="COIN-USDT",
        side=TradeType.BUY,
        price=100.0,
        amount=1.0,
        order_type=OrderType.MARKET,  # key: before-code incorrectly reports "limit_maker" for MARKET
        market="test_market",
        timestamp=1700000000.0,
        trade_fee=TradeFee(percent=0.001, flat_fees=[]),
    )

    df = Trade.to_pandas([trade])

    assert df.loc[0, "order_type"] == "market", (
        "Trade.to_pandas should populate the 'order_type' column using "
        "trade.order_type.name.lower() so OrderType.MARKET becomes 'market'. "
        "Hardcoded mappings like 'limit'/'limit_maker' are incorrect."
    )
    assert df.loc[0, "trade_side"] == "buy", (
        "Trade.to_pandas should populate the 'trade_side' column using "
        "trade.side.name.lower() so TradeType.BUY becomes 'buy'."
    )