import re


def test_copy_script_comment_present_and_spelling_fixed():
    """
    Functional intent of the review: ensure the code path that handles downloading a script
    explicitly documents that it *copies the script and files into an importable directory*.

    The "after" code adds the comment with corrected wording:
        '# copy the script and the files in an importable directory'

    The "before" code has the awkward/incorrect text:
        '# the copy the script and the files in an importable directory'
    """
    source = open("/workspace/src/datasets/load.py", "r", encoding="utf-8").read()

    assert (
        "# copy the script and the files in an importable directory" in source
    ), "Expected updated comment to be present: '# copy the script and the files in an importable directory'"

    assert (
        "# the copy the script and the files in an importable directory" not in source
    ), "Did not expect old/incorrect comment to remain: '# the copy the script and the files in an importable directory'"


def test_resource_copy_helper_function_renamed_resources_not_resouces():
    """
    The review comment is tied to the 'copy script and files' step; the corresponding helper
    was renamed/fixed from 'resouces' -> 'resources' in the 'after' code.
    This is a stable, observable source-level behavior change.
    """
    source = open("/workspace/src/datasets/load.py", "r", encoding="utf-8").read()

    assert re.search(
        r"def\s+_copy_script_and_other_resources_in_importable_dir\s*\(",
        source,
    ), "Expected helper function with corrected name '_copy_script_and_other_resources_in_importable_dir'"

    assert not re.search(
        r"def\s+_copy_script_and_other_resouces_in_importable_dir\s*\(",
        source,
    ), "Did not expect misspelled helper function name '_copy_script_and_other_resouces_in_importable_dir' to remain"