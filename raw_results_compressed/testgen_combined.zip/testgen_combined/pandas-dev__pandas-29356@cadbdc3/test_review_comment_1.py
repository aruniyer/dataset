import inspect

import pandas.tests.test_multilevel as tml


def test_test_subsets_multiindex_dtype_is_programmatic_not_hardcoded():
    """
    Structural regression test: ensure the GH20757 test was made programmatic
    (small, copy-pastable) instead of hardcoding a huge data/columns payload.

    This asserts that the test data is minimal and does not contain the large
    hardcoded sentinel values present in the pre-review version.
    """
    src = inspect.getsource(tml.TestMultiLevel.test_subsets_multiindex_dtype)

    assert 'data = [["x", 1]]' in src, (
        "Expected GH20757 regression test to use minimal programmatic data "
        '(e.g. data = [["x", 1]]) for copy/paste friendliness.'
    )

    assert 'columns = [("a", "b", np.nan), ("a", "c", 0.0)]' in src, (
        "Expected GH20757 regression test to use a short, programmatic columns list "
        "instead of a long hardcoded MultiIndex specification."
    )

    assert "1521734085.289453" not in src and "3233" not in src, (
        "Found large hardcoded sentinel values from the pre-review version; "
        "the test should be simplified/programmatic rather than containing the "
        "original long hardcoded payload."
    )