import pytest


def test_batch_enrich_cel_does_not_hardcode_limit_1000():
    """
    Regression test for PR review: ensure /batch_enrich CEL path no longer hard-codes
    a limit=1000 when building QueryDto for query_last_alerts.

    We verify this via a simple source inspection because the behavioral difference
    (paging/limit handling passed into query_last_alerts) is otherwise hard to observe
    without patching or a running DB.
    """
    source = open("/workspace/keep/api/routes/alerts.py", "r", encoding="utf-8").read()

    assert (
        "query=QueryDto(\n"
        "                    cel=enrich_data.cel,\n"
        "                    limit=enrich_data.limit,"
        not in source
    ), (
        "batch_enrich_alerts should not pass through enrich_data.limit/offset to QueryDto "
        "for CEL queries in a way that can reintroduce a hard-coded or oversized limit. "
        "Expected QueryDto(cel=enrich_data.cel) without explicit limit/offset in the CEL path."
    )

    assert "query=QueryDto(cel=enrich_data.cel)" in source, (
        "Expected batch_enrich_alerts CEL path to call query_last_alerts with "
        "QueryDto(cel=enrich_data.cel) (no explicit limit=1000)."
    )