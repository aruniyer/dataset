import re


def test_alpha_release_on_feature_branch_commits_to_same_branch_instead_of_release_branch():
    source = open("/workspace/scripts/release.py", encoding="utf-8").read()

    # The review request: for alpha releases, if current branch is neither master nor a
    # release branch (e.g. 1.2.x), release script should commit directly to the current
    # branch rather than creating a new "prepare-release-..." branch.
    #
    # We verify this by checking that the script contains:
    # - a helper that detects "master or release branch" (release branch pattern like \d+\.\d+\.x)
    # - a conditional alpha workflow that avoids create_release_branch(...) when not on master/release

    assert "git_current_branch_is_master_or_release" in source, (
        "Release script should define git_current_branch_is_master_or_release() to detect "
        "whether the current branch is 'master' or a release branch (e.g. '1.2.x')."
    )

    assert re.search(r"RELEASE_BRANCH_PATTERN\s*=\s*re\.compile\(", source), (
        "Release script should define RELEASE_BRANCH_PATTERN (compiled regex) to recognize "
        "release branches like '1.2.x'."
    )

    # Look for the alpha workflow condition introduced by the fix.
    assert (
        ("version.is_alpha" in source and "not git_current_branch_is_master_or_release()" in source)
        or re.search(r"if\s+.*is_alpha.*and\s+not\s+git_current_branch_is_master_or_release\(\)\s*:", source)
    ), (
        "Release script should special-case alpha releases on non-master/non-release branches "
        "and commit/push changes on the current branch instead of creating a release branch."
    )

    # Ensure the alpha-workflow branch does NOT create a release branch.
    # We check that the alpha-workflow 'if' block does not contain create_release_branch,
    # and that create_release_branch is only used in the 'else' branch.
    alpha_if_pos = source.find("if version.is_alpha")
    assert alpha_if_pos != -1, (
        "Expected an 'if version.is_alpha ...' block implementing the feature-branch alpha workflow."
    )

    else_pos = source.find("\n    else:", alpha_if_pos)
    assert else_pos != -1, (
        "Expected an 'else' branch after the alpha feature-branch workflow (master/release branch path)."
    )

    alpha_block = source[alpha_if_pos:else_pos]
    else_block = source[else_pos : min(len(source), else_pos + 1200)]

    assert "create_release_branch" not in alpha_block, (
        "For alpha releases on non-master/non-release branches, the script should NOT create a "
        "separate release branch; it should commit directly to the current branch."
    )
    assert "create_release_branch" in else_block, (
        "For non-alpha releases (or alpha releases on master/release branches), the script should "
        "still create a dedicated release branch via create_release_branch(...)."
    )