import re

import pytest


def test_scriptupdated_does_not_create_unused_stub_and_channel_is_bound():
    """
    Functional intent of the review comment:
    ScriptUpdated must not silently drop creating a RenderServerStub / binding the channel
    if it is required for WebGL renderer updates.

    Since we cannot import the module in this environment, verify via source inspection
    that ScriptUpdated uses the same channel+stub pattern as update_renderer_scene_data.
    This fails on the "before" code (channel created but no stub) and passes on "after".
    """
    source = open("/workspace/manim/grpc/impl/frame_server_impl.py", encoding="utf-8").read()

    # Extract ScriptUpdated body (simple, robust-enough regex without AST).
    m = re.search(
        r"def ScriptUpdated\(self, request, context\):(.*?)(?=\n\s*def\s)",
        source,
        flags=re.S,
    )
    assert m, "Expected to find FrameServer.ScriptUpdated method in frame_server_impl.py"
    body = m.group(1)

    assert 'grpc.insecure_channel("localhost:50052") as channel' in body, (
        "ScriptUpdated should bind the grpc channel as 'channel' (with 'as channel') "
        "so a RenderServerStub can be created; otherwise the channel context is unused."
    )
    assert "renderserver_pb2_grpc.RenderServerStub(channel)" in body, (
        "ScriptUpdated should create a RenderServerStub from the channel; removing this "
        "is not safe because there are no WebGL renderer tests guaranteeing it's unused."
    )