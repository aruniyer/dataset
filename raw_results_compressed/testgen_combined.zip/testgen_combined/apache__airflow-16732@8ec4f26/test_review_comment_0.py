import pytest

import airflow.models.baseoperator as baseoperator


def test_chain_typeerror_message_uses_single_quotes_not_stylistic_double_quotes():
    """
    Style regression test: the TypeError message in chain() should remain
    single-quoted in the source (avoid stylistic-only double-quote change).
    This is only observable reliably via source inspection.
    """
    source = open("/workspace/airflow/models/baseoperator.py", encoding="utf-8").read()

    expected_single_quoted = (
        "'Chain not supported between instances of {up_type} and {down_type}'.format("
    )
    disallowed_double_quoted = (
        '"Chain not supported between instances of {up_type} and {down_type}".format('
    )

    assert (
        expected_single_quoted in source
    ), "Expected chain() to use the original single-quoted error message string (avoid stylistic-only quote change)."

    assert (
        disallowed_double_quoted not in source
    ), "chain() should not switch the error message to double quotes; this is a stylistic-only change."