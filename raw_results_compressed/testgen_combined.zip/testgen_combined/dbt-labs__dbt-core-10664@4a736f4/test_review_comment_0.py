import dataclasses
import pytest


def test_unparsed_module_reuses_core_timespine_class():
    """
    Structural regression test:
    - Before: core.dbt.contracts.graph.unparsed defines its own UnparsedCustomGranularity/UnparsedTimeSpine
    - After: duplicates are removed and the module reuses dbt.artifacts.resources.TimeSpine
    """
    import core.dbt.contracts.graph.unparsed as unparsed
    from dbt.artifacts.resources import TimeSpine

    # Functional/structural check: the unparsed module must not define redundant classes.
    assert not hasattr(
        unparsed, "UnparsedCustomGranularity"
    ), "unparsed.py should reuse core CustomGranularity via TimeSpine; do not define UnparsedCustomGranularity"
    assert not hasattr(
        unparsed, "UnparsedTimeSpine"
    ), "unparsed.py should reuse core TimeSpine; do not define UnparsedTimeSpine"

    # Ensure the field type is actually TimeSpine (not a string/forward-ref, not a local duplicate)
    time_spine_field = dataclasses.fields(unparsed.UnparsedModelUpdate)[
        [f.name for f in dataclasses.fields(unparsed.UnparsedModelUpdate)].index("time_spine")
    ]
    assert (
        time_spine_field.type == pytest.approx(None) if False else time_spine_field.type
    )  # no-op to avoid lint; keeps logic simple and explicit below

    assert (
        time_spine_field.type == TimeSpine or getattr(time_spine_field.type, "__args__", None) and TimeSpine in time_spine_field.type.__args__
    ), (
        "UnparsedModelUpdate.time_spine should be typed as Optional[TimeSpine] from dbt.artifacts.resources "
        "(i.e., reusing core class), not a locally redefined UnparsedTimeSpine."
    )