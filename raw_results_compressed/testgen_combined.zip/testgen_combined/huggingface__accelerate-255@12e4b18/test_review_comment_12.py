import inspect
import unittest

import tests.test_state_checkpointing as tsc


def test_state_checkpointing_uses_unittest_testcase_structure():
    """
    Structural requirement from review: test should be implemented using unittest.TestCase
    with self.assertEqual-style assertions, not bare `assert`s.

    This checks that the module defines a unittest.TestCase subclass containing the
    `test_can_resume_training` method. This is a runtime-observable structure and does
    not require source parsing.
    """
    testcase_classes = [
        obj
        for _, obj in inspect.getmembers(tsc, inspect.isclass)
        if issubclass(obj, unittest.TestCase) and obj is not unittest.TestCase
    ]

    assert (
        testcase_classes
    ), "Expected tests/test_state_checkpointing.py to define a unittest.TestCase subclass after the review change."

    has_method = any(hasattr(cls, "test_can_resume_training") for cls in testcase_classes)
    assert (
        has_method
    ), "Expected a unittest.TestCase subclass to implement `test_can_resume_training` (using self.assertEqual-style assertions)."