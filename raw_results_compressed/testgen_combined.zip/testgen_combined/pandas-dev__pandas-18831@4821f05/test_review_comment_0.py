import inspect

import pandas.tests.series.test_operators as ops_mod


def test_timedelta_scalar_ops_are_parametrized_and_not_in_datetime_class():
    """
    Structural check for GH#18831-era refactor:

    The "before" version had TestDatetimeSeriesArithmetic.test_timedelta_rfloordiv
    and embedded several similar timedelta scalar floor-div assertions inside
    TestDatetimeSeriesArithmetic.test_operators_datetimelike.

    The "after" version moves these into dedicated parametrized tests under
    TestTimedeltaSeriesArithmetic:
      - test_timedelta_rfloordiv (parametrized, with an xfail param)
      - test_timedelta_rfloordiv_explicit (parametrized)
      - test_timedelta_floordiv (parametrized)

    This test fails on "before" and passes on "after" by asserting:
      1) the new parametrized tests exist on TestTimedeltaSeriesArithmetic, and
      2) the old non-parametrized test is no longer present on
         TestDatetimeSeriesArithmetic.
    """
    assert hasattr(
        ops_mod, "TestTimedeltaSeriesArithmetic"
    ), "Expected TestTimedeltaSeriesArithmetic to exist in pandas.tests.series.test_operators"

    timed = ops_mod.TestTimedeltaSeriesArithmetic
    for name in [
        "test_timedelta_rfloordiv",
        "test_timedelta_rfloordiv_explicit",
        "test_timedelta_floordiv",
    ]:
        assert hasattr(
            timed, name
        ), f"Expected {name} to be defined on TestTimedeltaSeriesArithmetic after refactor"

        fn = getattr(timed, name)
        assert hasattr(
            fn, "pytestmark"
        ), f"Expected {name} to be parametrized (have pytest marks); missing pytestmark"

        marks = fn.pytestmark
        if not isinstance(marks, (list, tuple)):
            marks = [marks]
        assert any(
            getattr(m, "name", None) == "parametrize" for m in marks
        ), f"Expected {name} to have a @pytest.mark.parametrize decorator"

    assert hasattr(
        ops_mod, "TestDatetimeSeriesArithmetic"
    ), "Expected TestDatetimeSeriesArithmetic to exist in pandas.tests.series.test_operators"

    assert not hasattr(
        ops_mod.TestDatetimeSeriesArithmetic, "test_timedelta_rfloordiv"
    ), (
        "Expected old TestDatetimeSeriesArithmetic.test_timedelta_rfloordiv to be removed "
        "and replaced by parametrized tests under TestTimedeltaSeriesArithmetic"
    )

    # Extra guard: ensure the datetime-like operator-smoke test no longer contains
    # explicit floor-div assertions for timedelta scalars.
    dt_fn = ops_mod.TestDatetimeSeriesArithmetic.test_operators_datetimelike
    src = inspect.getsource(dt_fn)
    assert "//" not in src, (
        "Expected timedelta scalar floor-division checks to be moved out of "
        "TestDatetimeSeriesArithmetic.test_operators_datetimelike into dedicated "
        "parametrized tests; found '//' in source."
    )