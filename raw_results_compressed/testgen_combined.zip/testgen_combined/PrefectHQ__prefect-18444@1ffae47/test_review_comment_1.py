import re


def test_client_settings_custom_headers_has_pydantic_compat_comment():
    """
    Regression test for a pydantic compatibility issue:
    `custom_headers` must remain annotated as `typing.Dict[str, str]` (not `dict[str, str]`)
    due to incompatibility with pydantic < 2.11, and the source should document this.
    """
    source = open("/workspace/src/prefect/settings/models/client.py", "r", encoding="utf-8").read()

    assert re.search(r"^\s*custom_headers\s*:\s*Dict\s*\[\s*str\s*,\s*str\s*\]\s*=", source, re.M), (
        "Expected `custom_headers` to be annotated as `Dict[str, str]` in "
        "/workspace/src/prefect/settings/models/client.py for pydantic compatibility."
    )

    assert (
        "pydantic < 2.11" in source
        and "dict[str, str]" in source
        and "custom_headers" in source
    ), (
        "Expected an in-source comment explaining why `custom_headers` uses `typing.Dict` "
        "(mentioning pydantic < 2.11 and `dict[str, str]` incompatibility)."
    )