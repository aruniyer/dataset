import re


def _class_block(source: str, class_name: str) -> str:
    m = re.search(
        rf"^class {re.escape(class_name)}:\n(?P<body>[\s\S]*?)(?=^\S|\Z)",
        source,
        flags=re.MULTILINE,
    )
    assert m is not None, f"Expected to find `class {class_name}:` in the source file"
    return m.group("body")


def _method_block_from_class(class_body: str, method_name: str) -> str:
    """
    Extract full method block (signature + body) for a method defined at 4-space indent
    within a class body.
    """
    m = re.search(
        rf"^    (?:async def|def) {re.escape(method_name)}\([\s\S]*?\):\n"
        rf"(?P<body>[\s\S]*?)(?=^    (?:async def|def) |\Z)",
        class_body,
        flags=re.MULTILINE,
    )
    assert m is not None, (
        f"Expected to find `{method_name}` method inside class body, but it was not found."
    )
    return m.group(0)


def test_stream_prefetch_respects_explicit_argument_over_instance_default():
    """
    Ensure RequestStreamer.stream does NOT clobber an explicit `prefetch` argument with
    `self._prefetch`. The fixed code should contain:
        prefetch = prefetch or self._prefetch
    """
    source = open("/workspace/jina/serve/stream/__init__.py", "r", encoding="utf-8").read()
    cls_body = _class_block(source, "RequestStreamer")
    stream_block = _method_block_from_class(cls_body, "stream")

    assert "prefetch = prefetch or self._prefetch" in stream_block, (
        "RequestStreamer.stream should default `prefetch` to `self._prefetch` only when the "
        "caller does not provide it (expected `prefetch = prefetch or self._prefetch`)."
    )

    # Guard against the buggy unconditional overwrite.
    assert not re.search(
        r"^\s*prefetch\s*=\s*self\._prefetch\s*$", stream_block, re.MULTILINE
    ), (
        "RequestStreamer.stream must not unconditionally overwrite caller-provided `prefetch` "
        "with `self._prefetch` (old buggy behavior)."
    )