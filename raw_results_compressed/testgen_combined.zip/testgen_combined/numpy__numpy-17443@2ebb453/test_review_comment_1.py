def test_setup_warns_only_for_python_ge_310_not_ge_39():
    """
    The review requested keeping the warning threshold consistent with the
    Python version Trove classifiers.

    Concretely, the code changed from:
        if sys.version_info >= (3, 9):
    to:
        if sys.version_info >= (3, 10):

    This test asserts that the threshold is exactly (3, 10) and not (3, 9).
    """
    source = open("/workspace/setup.py", "r", encoding="utf-8").read()

    assert "if sys.version_info >= (3, 10):" in source, (
        "Expected setup.py to warn only for Python >= 3.10 (i.e. "
        "contain 'if sys.version_info >= (3, 10):'), keeping it consistent with "
        "the listed 'Programming Language :: Python :: ...' classifiers."
    )

    assert "if sys.version_info >= (3, 9):" not in source, (
        "setup.py still contains 'if sys.version_info >= (3, 9):' which was the "
        "inconsistent pre-fix threshold; it should have been updated to (3, 10)."
    )