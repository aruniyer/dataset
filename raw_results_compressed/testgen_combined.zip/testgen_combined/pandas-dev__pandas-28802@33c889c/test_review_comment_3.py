import numpy as np
import pandas.core.reshape.tile as tile


def test__coerce_to_type_bool_returns_dtype_none_and_int64_array():
    """
    Regression test for GH 20303 handling in _coerce_to_type.

    Before fix: bool input set dtype=x.dtype (not None), then entered the
    `if dtype is not None:` block and attempted to call `x.notna()` on a numpy
    ndarray, raising AttributeError. (The review comment's point is that dtype
    should stay None for bools.)

    After fix: bool input is converted to int64 and dtype remains None.
    """
    x = np.array([True, False, True], dtype=bool)

    # Must not raise, and must match the new contract:
    # - bools coerced to int64 values
    # - dtype left as None (only used for datetimelike)
    coerced, dtype = tile._coerce_to_type(x)

    assert dtype is None, (
        "For boolean input, _coerce_to_type should leave dtype=None (dtype is "
        "intended for datetimelike cut/qcut paths). In the pre-fix code it "
        "incorrectly set dtype to bool, triggering the dtype!=None conversion block."
    )
    assert coerced.dtype == np.int64, "Boolean input should be coerced to int64."
    assert np.array_equal(coerced, np.array([1, 0, 1], dtype=np.int64)), (
        "Boolean values should be coerced to their integer representation (True->1, False->0)."
    )