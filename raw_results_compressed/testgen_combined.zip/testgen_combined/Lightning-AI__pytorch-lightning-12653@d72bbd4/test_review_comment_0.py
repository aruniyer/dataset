import warnings

from torch.utils.data import DataLoader, Dataset, Sampler

from pytorch_lightning.trainer.connectors.data_connector import DataConnector
from pytorch_lightning.trainer.states import RunningStage
from pytorch_lightning.utilities.warnings import PossibleUserWarning


class _DummyDataset(Dataset):
    def __len__(self):
        return 8

    def __getitem__(self, idx):
        return idx


class _CustomSequentialSampler(Sampler):
    """A user-provided sampler (not RandomSampler/SequentialSampler) that yields sequential indices."""

    def __init__(self, data_source):
        self.data_source = data_source

    def __iter__(self):
        return iter(range(len(self.data_source)))

    def __len__(self):
        return len(self.data_source)


def test_check_eval_shuffling_warns_for_custom_sampler_when_shuffle_true():
    dataset = _DummyDataset()
    sampler = _CustomSequentialSampler(dataset)

    # DataLoader keeps shuffle=True even with a custom sampler. The "after" behavior
    # (moving the conditions into `_is_dataloader_shuffled`) warns in this case.
    dl = DataLoader(dataset, batch_size=2, shuffle=True, sampler=sampler)

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        DataConnector._check_eval_shuffling(dl, mode=RunningStage.VALIDATING)

    pl_shuffle_warnings = [w for w in caught if issubclass(w.category, PossibleUserWarning)]
    assert (
        len(pl_shuffle_warnings) == 1
    ), "Expected Lightning to emit a PossibleUserWarning about shuffling in eval when DataLoader(shuffle=True), even if a custom sampler is provided (current 'after' behavior)."
    assert "sampler has shuffling enabled" in str(
        pl_shuffle_warnings[0].message
    ), "The warning message should indicate that the dataloader sampler has shuffling enabled."