import numpy as np
import pandas as pd

import pandas.tests.frame.test_indexing as mod


def test_test_setitem_mixed_datetime_uses_direct_numpy_array_assignment():
    """
    Review comment requested constructing a NumPy array directly for assignment
    (instead of building a DataFrame and using .values).

    This test asserts that the test implementation in
    /workspace/pandas/tests/frame/test_indexing.py reflects that change by
    checking the function source for:
      - use of np.array([...]) to build the assigned values
      - direct assignment of that array (df.loc[...] = A)
      - no intermediate DataFrame creation for A (pd.DataFrame(...))
    """
    # Get the source text for just the method body to avoid matching other tests
    source = open("/workspace/pandas/tests/frame/test_indexing.py", "r", encoding="utf-8").read()
    marker = "def test_setitem_mixed_datetime(self):"
    start = source.find(marker)
    assert start != -1, "Could not find test_setitem_mixed_datetime definition in source file"

    # Grab a reasonable slice until the next test definition
    end = source.find("\n    def ", start + len(marker))
    assert end != -1, "Could not find end of test_setitem_mixed_datetime block in source file"
    block = source[start:end]

    assert "A = np.array(" in block, (
        "Expected test_setitem_mixed_datetime to construct assigned values with a direct "
        "NumPy array (A = np.array(...)), per review comment."
    )
    assert "df.loc[[4, 5], ['a', 'b']] = A" in block, (
        "Expected test_setitem_mixed_datetime to assign the NumPy array directly "
        "(df.loc[...] = A), not via A.values."
    )
    assert "A = pd.DataFrame" not in block, (
        "Did not expect test_setitem_mixed_datetime to build A as a DataFrame; "
        "review comment requested constructing a NumPy array directly."
    )


def test_setitem_mixed_datetime_behavior_still_matches_expected():
    """
    Sanity check: the mixed-dtype assignment scenario still yields expected result.
    This is not the before/after differentiator; it just ensures the scenario remains valid.
    """
    expected = pd.DataFrame(
        {
            "a": [0, 0, 0, 0, 13, 14],
            "b": [
                pd.datetime(2012, 1, 1),
                1,
                "x",
                "y",
                pd.datetime(2013, 1, 1),
                pd.datetime(2014, 1, 1),
            ],
        }
    )

    df = pd.DataFrame(0, columns=list("ab"), index=range(6))
    df["b"] = pd.NaT
    df.loc[0, "b"] = pd.datetime(2012, 1, 1)
    df.loc[1, "b"] = 1
    df.loc[[2, 3], "b"] = "x", "y"

    A = np.array(
        [
            [13, np.datetime64("2013-01-01T00:00:00")],
            [14, np.datetime64("2014-01-01T00:00:00")],
        ],
        dtype=object,
    )
    df.loc[[4, 5], ["a", "b"]] = A

    mod.assert_frame_equal(df, expected)