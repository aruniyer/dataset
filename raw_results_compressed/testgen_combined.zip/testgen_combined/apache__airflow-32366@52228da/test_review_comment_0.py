import re


def test_no_temporary_pydantic_fallback_hack_in_install_script():
    """
    The reviewed change introduced a temporary hack:
      || pip install 'pydantic>=2' || true

    The review comment states this hack (and similar ones) will be removed before merge.
    This test ensures the install script does not contain that fallback.
    """
    path = "/workspace/scripts/docker/install_airflow_dependencies_from_branch_tip.sh"
    source = open(path, encoding="utf-8").read()

    assert "pip install 'pydantic>=2'" not in source, (
        "Temporary dependency-install fallback detected in "
        f"{path}: found \"pip install 'pydantic>=2'\". "
        "This hack was intended to be removed before merge."
    )

    # Extra guard: ensure the exact OR-chain style hack is not present either.
    assert not re.search(r"\|\|\s*pip\s+install\s+'pydantic>=2'\s*\|\|\s*true", source), (
        f"Temporary OR-chain hack \"|| pip install 'pydantic>=2' || true\" is still present in {path}. "
        "It should be removed."
    )