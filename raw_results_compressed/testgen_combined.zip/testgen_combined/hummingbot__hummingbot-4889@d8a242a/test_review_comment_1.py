import re


def test_asyncio_sleep_is_not_patched_directly_in_mexc_order_book_tests():
    """
    Ensures the mexc order book data source unit tests do NOT patch asyncio.sleep directly,
    and instead patch the data source wrapper method (_sleep), as requested in the review comment.
    """
    source_path = "/workspace/test/hummingbot/connector/exchange/mexc/test_mexc_api_order_book_data_source.py"
    source = open(source_path, "r", encoding="utf-8").read()

    assert (
        '@patch("asyncio.sleep")' not in source
    ), (
        "The test file patches asyncio.sleep directly. This is discouraged because it can affect other code paths. "
        "Patch the wrapper method (e.g. MexcAPIOrderBookDataSource._sleep) instead."
    )

    assert re.search(
        r'@patch\("hummingbot\.connector\.exchange\.mexc\.mexc_api_order_book_data_source\.'
        r'MexcAPIOrderBookDataSource\._sleep"\)',
        source,
    ), (
        "Expected the test file to patch MexcAPIOrderBookDataSource._sleep (the wrapper around asyncio.sleep), "
        "but no such patch was found."
    )