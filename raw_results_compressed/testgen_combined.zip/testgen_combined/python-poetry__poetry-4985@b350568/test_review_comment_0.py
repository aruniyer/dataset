import re

import src.poetry.utils.env as env


def test_get_python_version_oneliner_constant_exists_and_matches_expected() -> None:
    """
    Style regression test for env.py: the repeated one-liner python version script
    should be defined once as GET_PYTHON_VERSION_ONELINER and reused.
    """
    assert hasattr(
        env, "GET_PYTHON_VERSION_ONELINER"
    ), (
        "Expected src.poetry.utils.env to define GET_PYTHON_VERSION_ONELINER to avoid "
        "repeating/line-wrapping the python '-c' version script; this should exist "
        "after the style refactor."
    )

    value = env.GET_PYTHON_VERSION_ONELINER
    assert isinstance(
        value, str
    ), "GET_PYTHON_VERSION_ONELINER should be a string constant."

    expected = "\"import sys; print('.'.join([str(s) for s in sys.version_info[:3]]))\""
    assert (
        value == expected
    ), "GET_PYTHON_VERSION_ONELINER should match the exact expected one-liner script."

    # Additional sanity: ensure it is truly a one-liner (no embedded newlines).
    assert (
        "\n" not in value and "\r" not in value
    ), "GET_PYTHON_VERSION_ONELINER should not contain newlines; it must be a one-liner."

    # Ensure it looks like the quoted -c script (starts/ends with a quote character).
    assert re.match(r'^".*"$', value) is not None, (
        "GET_PYTHON_VERSION_ONELINER should be wrapped in double-quotes as passed to "
        "python -c via list_to_shell_command()."
    )