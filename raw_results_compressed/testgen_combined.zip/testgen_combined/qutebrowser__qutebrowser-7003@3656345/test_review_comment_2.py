import re


def test_downloads_feature_uses_prompt_fileselect_external_step():
    """Ensure the external fileselect download scenario uses the correct prompt step.

    This is the functional behavior requested in the review comment:
    use ':prompt-fileselect-external' (not ':prompt-external-picker').
    """
    path = "/workspace/tests/end2end/features/downloads.feature"
    source = open(path, encoding="utf-8").read()

    assert (
        ":prompt-fileselect-external" in source
    ), "Expected downloads.feature to use ':prompt-fileselect-external' for the external fileselect download prompt."

    assert (
        ":prompt-external-picker" not in source
    ), "Did not expect legacy/incorrect ':prompt-external-picker' step to remain in downloads.feature."

    # Tighten: ensure the 'Select download path' scenario contains the correct step.
    m = re.search(
        r"Scenario:\s*Select download path(?P<body>.*?)(?:\n\s*Scenario:|\Z)",
        source,
        flags=re.DOTALL,
    )
    assert m, "Could not locate 'Scenario: Select download path' in downloads.feature."

    scenario_body = m.group("body")
    assert (
        ":prompt-fileselect-external" in scenario_body
    ), "In 'Scenario: Select download path', expected ':prompt-fileselect-external' step to be present."
    assert (
        ":prompt-external-picker" not in scenario_body
    ), "In 'Scenario: Select download path', ':prompt-external-picker' should not be used."