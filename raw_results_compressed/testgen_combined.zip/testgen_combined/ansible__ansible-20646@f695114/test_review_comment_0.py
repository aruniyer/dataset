import pytest

import lib.ansible.modules.cloud.amazon.rds as rds


class DummyModule:
    def __init__(self, params):
        self.params = params

    def fail_json(self, msg):
        raise RuntimeError(msg)


def test_validate_parameters_accepts_non_boolean_optional_params_when_set():
    """
    validate_parameters should treat optional params as "provided" when they are not None,
    even if they are non-boolean falsy/truthy values (e.g. size=0, iops=1000, license_model='...').

    This test specifically checks that a non-boolean optional param (iops) is passed through
    for a command where it is valid (create). The buggy implementation only considered booleans.
    """
    module = DummyModule(
        params={
            "command": "create",
            # required vars for create:
            "instance_name": "db1",
            "db_engine": "MySQL",
            "size": 10,
            "instance_type": "db.t3.micro",
            "username": "u",
            "password": "p",
            # optional, valid var for create:
            "iops": 1000,
            # ensure other branches don't trigger
            "security_groups": None,
            "vpc_security_groups": None,
            "tags": None,
            "publicly_accessible": None,
        }
    )

    required_vars = ["instance_name", "db_engine", "size", "instance_type", "username", "password"]
    valid_vars = [
        "backup_retention",
        "backup_window",
        "character_set_name",
        "db_name",
        "engine_version",
        "instance_type",
        "iops",
        "license_model",
        "maint_window",
        "multi_zone",
        "option_group",
        "parameter_group",
        "port",
        "subnet",
        "upgrade",
        "zone",
        "security_groups",
    ]

    params = rds.validate_parameters(required_vars, valid_vars, module)

    assert "iops" in params, (
        "Expected validate_parameters() to include non-boolean optional parameter 'iops' "
        "when it is set (not None) and valid for the command. "
        "This ensures the check uses 'is not None' rather than only accepting booleans."
    )
    assert params["iops"] == 1000, "Expected validate_parameters() to pass through iops value unchanged."