import numpy as np
import pytest


def test_einsum_test_different_paths_uses_half_offsets_and_exact_sum_check():
    """
    Regression test for the rounding-instability noted in the review:
    the added einsum path-exercising test must use +0.5 (not +0.1) so that
    sums/products are exactly representable and equality comparisons are stable
    across platforms (arm64, s390x).

    This test is intentionally source-level: the behavior change is in the test
    suite itself (numpy.core.tests.test_einsum), not in numpy.einsum.
    """
    src = open("/workspace/numpy/core/tests/test_einsum.py", "r", encoding="utf-8").read()

    assert "def test_different_paths" in src, (
        "Expected numpy/core/tests/test_einsum.py to define the regression test "
        "'test_different_paths'."
    )

    assert "np.arange(7) + 0.5" in src, (
        "The regression test 'test_different_paths' must use '+ 0.5' when creating "
        "the array (exactly representable), to avoid platform-dependent float "
        "rounding differences (e.g. 95.270004 vs 95.27)."
    )

    assert "np.arange(7) + 0.1" not in src, (
        "The regression test should not use '+ 0.1' because it can lead to "
        "platform-dependent rounding and flaky equality assertions."
    )

    assert "assert res == arr.sum()" in src, (
        "The regression test should compare einsum reduction to arr.sum() exactly "
        "when using +0.5, rather than hardcoding a float literal that can differ "
        "in representation/rounding."
    )