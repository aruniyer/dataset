import re


def test_update_password_always_does_not_test_credentials():
    """
    Structural guarantee: when update_password == "always", the module should NOT
    call Test-Credential (because it will set the password unconditionally).

    This test fails on the old structure where Test-Credential is executed under
    update_password in @("always"; "when_changed"), and passes on the refactor
    where Test-Credential is only used for update_password == "when_changed".
    """
    source = open("/workspace/lib/ansible/modules/windows/win_domain_user.ps1", encoding="utf-8").read()

    # PASS condition: "when_changed" branch explicitly uses Test-Credential (new structure)
    when_changed_uses_test_cred = re.search(
        r'\$update_password\s*-eq\s*"when_changed"[\s\S]{0,300}?Test-Credential',
        source,
        flags=re.IGNORECASE,
    )
    assert when_changed_uses_test_cred, (
        "Expected refactored structure where update_password == 'when_changed' uses "
        "Test-Credential to decide whether to set the password."
    )

    # FAIL condition (old structure): update_password in @("always"; "when_changed") gating
    # combined with Test-Credential call in that block means 'always' can still test credentials.
    old_always_when_changed_gate = re.search(
        r'\$update_password\s*-in\s*@\(\s*"always"\s*;\s*"when_changed"\s*\)',
        source,
        flags=re.IGNORECASE,
    )
    assert not old_always_when_changed_gate, (
        "update_password == 'always' must not be grouped with 'when_changed' in a condition "
        "that can lead to Test-Credential being called. The refactor should separate "
        "'always' (unconditional set) from 'when_changed' (credential test)."
    )