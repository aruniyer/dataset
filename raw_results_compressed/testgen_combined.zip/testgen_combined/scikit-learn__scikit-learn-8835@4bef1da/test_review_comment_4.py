import re


def test_removed_dtype_missmatch_test_function():
    source_path = "/workspace/sklearn/linear_model/tests/test_logistic.py"
    source = open(source_path, "r", encoding="utf-8").read()

    assert "def test_dtype_match():" in source, (
        "Expected test_dtype_match to exist in test_logistic.py."
    )

    assert "def test_dtype_missmatch_to_profile():" not in source, (
        "The review comment indicates an unnecessary test should be removed. "
        "Expected `test_dtype_missmatch_to_profile` to be absent, but it is still present."
    )


def test_dtype_match_extended_to_cover_sparse_and_explicit_float64():
    source_path = "/workspace/sklearn/linear_model/tests/test_logistic.py"
    source = open(source_path, "r", encoding="utf-8").read()

    # Structural expectations for the revised test_dtype_match:
    # - explicit float32/float64 variables instead of generic X_/y_
    # - sparse float32 coverage
    required_snippets = [
        "X_32 = np.array(X).astype(np.float32)",
        "y_32 = np.array(Y1).astype(np.float32)",
        "X_64 = np.array(X).astype(np.float64)",
        "y_64 = np.array(Y1).astype(np.float64)",
        "X_sparse_32 = sp.csr_matrix(X, dtype=np.float32)",
    ]
    for snippet in required_snippets:
        assert snippet in source, (
            f"Expected `test_dtype_match` to include `{snippet}` to cover explicit "
            "float32/float64 and sparse float32 inputs."
        )

    # Also ensure there's a sparse fit check in the test body.
    assert re.search(r"lr_32_sparse\.fit\(\s*X_sparse_32\s*,\s*y_32\s*\)", source), (
        "Expected `test_dtype_match` to fit a LogisticRegression model on X_sparse_32 "
        "and y_32 to check dtype behavior for sparse inputs."
    )